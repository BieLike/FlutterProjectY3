import 'package:flutter/material.dart';

class FetchDataNow extends StatefulWidget {
  const FetchDataNow({super.key});

  @override
  State<FetchDataNow> createState() => _FetchDataNowState();
}

class _FetchDataNowState extends State<FetchDataNow> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}